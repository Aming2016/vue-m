const state = {
  token: "123123",
};
// getters
const getters = {
  token: (state) => state.token,
};
// mutations
const mutations = {};
const actions = {};

export default {
  state,
  getters,
  actions,
  mutations,
};
