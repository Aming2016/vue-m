<template>
  <div class="mine">
    mine
  </div>
</template>

<script>
// @ is an alias to /src

export default {
  name: 'Mine',
  }
</script>
