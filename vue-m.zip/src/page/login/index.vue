<template>
  <div class="login">
  login
  </div>
</template>

<script>

export default {
  name: 'login'
}
</script>
